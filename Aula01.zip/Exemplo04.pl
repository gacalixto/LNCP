u(a,b).
u(b,b).
u(c,d).
u(c,a).
u(d,a).
u(d,c).

