p(a,c).
p(a,b).
p(d,a).
p(d,b).
